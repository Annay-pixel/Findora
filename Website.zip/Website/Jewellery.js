function toggleDiv1() {
    document.getElementById("Jewellery-women").style.display = "block";
    document.getElementById("Jewellery-men").style.display = "none";
}
function toggleDiv2() {
    document.getElementById("Jewellery-men").style.display = "block";
    document.getElementById("Jewellery-women").style.display = "none";
}