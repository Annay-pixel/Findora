function toggleDiv2() {
  document.getElementById("Apparel-all").style.display = "none";
  document.getElementById("Apparel-men").style.display = "block";
  document.getElementById("Apparel-women").style.display = "none";
  document.getElementById("Apparel-kids").style.display = "none";
}

function toggleDiv3() {
  document.getElementById("Apparel-all").style.display = "none";
  document.getElementById("Apparel-women").style.display = "block";
  document.getElementById("Apparel-kids").style.display = "none";
  document.getElementById("Apparel-men").style.display = "none";
}
function toggleDiv1() {
  document.getElementById("Apparel-all").style.display = "block";
  document.getElementById("Apparel-women").style.display = "none";
  document.getElementById("Apparel-men").style.display = "none";
  document.getElementById("Apparel-kids").style.display = "none";
}
function toggleDiv4() {
  document.getElementById("Apparel-all").style.display = "none";
  document.getElementById("Apparel-kids").style.display = "block";
  document.getElementById("Apparel-women").style.display = "none";
  document.getElementById("Apparel-men").style.display = "none";

}
